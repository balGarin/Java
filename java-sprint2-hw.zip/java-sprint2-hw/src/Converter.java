public class Converter {


    double convertToKm(int steps) {
        return steps * 0.00075;
    }

    double convertStepsToKilocalories(int steps) {
        return steps * 0.05;
    }

}
