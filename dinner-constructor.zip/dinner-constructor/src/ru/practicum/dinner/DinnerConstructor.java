package ru.practicum.dinner;

import com.sun.source.tree.Tree;

import java.util.*;

public class DinnerConstructor {
    Map<String, List<String>> menu;
    Random random;
    /*Добрый день, спасибо огромное за комментарии, правильно ли я понял - основная причина в том
    что в противном случае я не смогу в дальнейшем сделать так если мне это понадобится: menu = new TreeMap<>();
     или так menu = new LinkedHashMap<>(); то есть всегда стоит в типе ссылки использовать общий интерфейс,
      а не конкретную реализацию */


    DinnerConstructor() {
        menu = new HashMap<>();
        random = new Random();

    }

    void setMenu(String type, String dish) {

        if (menu.containsKey(type)) {
            List<String> dishes = menu.get(type);
            if (dishes.contains(dish)) {
                System.out.println("Такое блюдо уже есть в этом типе...\n");
                return;
            }
            dishes.add(dish);
            System.out.println("Блюдо добавлено!\n");
        } else {
            List<String> dishes = new ArrayList<>();
            dishes.add(dish);
            menu.put(type, dishes);
            System.out.println("Тип создан, блюдо добавлено!\n");
        }
    }

    void getCombo(int numberOfCombo, List<String> listOfTypes) {
        List<String> combo;
        for (int i = 1; i <= numberOfCombo; i++) {
            combo = new ArrayList<>();
            for (String type : menu.keySet()) {
                for (String comboType : listOfTypes) {
                    if (type.equals(comboType)) {
                        List<String> dishes = menu.get(type);
                        combo.add(dishes.get(random.nextInt(dishes.size())));
                    }
                }
            }
            System.out.println("Комбо № " + i);
            System.out.println(combo);
        }
        System.out.println();
    }

    boolean checkType(String type) {
        if (menu.containsKey(type) || type.isEmpty()) {
            return true;
        } else {
            System.out.println("Ошибка ввода : Пожалуйста введите существующий тип :");
            return false;
        }
    }

}
